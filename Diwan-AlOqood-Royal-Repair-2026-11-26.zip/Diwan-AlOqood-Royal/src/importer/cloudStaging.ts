import * as FileSystem from 'expo-file-system/legacy';
import { sha256 } from 'js-sha256';
import { toByteArray } from 'base64-js';
import { ungzip } from 'pako';
import { getDb } from '../database/db';

const CLOUD_BASE = 'https://diwan-contracts.vercel.app';

// These four catalog paths were found as literal asset paths in the supplied original APK.
// They are downloaded into a quarantine/staging area only; they are never merged automatically.
export const CLOUD_CATALOGS = [
  { id: 'administrative', label: 'الفهرس الإداري', path: '/assets/assets/content/mks/v1/administrative/catalog-000.json.gz' },
  { id: 'cassation', label: 'فهرس أحكام النقض', path: '/assets/assets/content/mks/v1/cassation/catalog-000.json.gz' },
  { id: 'constitutional', label: 'الفهرس الدستوري', path: '/assets/assets/content/mks/v1/constitutional/catalog-000.json.gz' },
  { id: 'decisions', label: 'فهرس القرارات', path: '/assets/assets/content/mks/v1/decisions/catalog-000.json.gz' },
  { id: 'laws', label: 'فهرس القوانين', path: '/assets/assets/content/mks/v1/laws/catalog-000.json.gz' },
] as const;

export type StagedCloudFile = {
  id: string; label: string; localUri: string; bytes: number; sha256: string;
  status: 'verified_staged'; downloadedAt: string;
};

function getStagingDirectory() {
  if (!FileSystem.documentDirectory) throw new Error('مساحة تخزين التطبيق غير متاحة على هذا الجهاز.');
  return `${FileSystem.documentDirectory}cloud-staging/`;
}

export async function listStagedCloudFiles(): Promise<StagedCloudFile[]> {
  const db = await getDb();
  return db.getAllAsync<StagedCloudFile>(
    'SELECT id, label, local_uri as localUri, bytes, sha256, status, downloaded_at as downloadedAt FROM cloud_staged_files ORDER BY downloaded_at DESC'
  );
}

export async function downloadCloudCatalogs(
  onProgress?: (label: string, completed: number, total: number) => void
): Promise<StagedCloudFile[]> {
  const directory = getStagingDirectory();
  await FileSystem.makeDirectoryAsync(directory, { intermediates: true });
  const db = await getDb();
  const saved: StagedCloudFile[] = [];
  const failures: string[] = [];

  for (let i = 0; i < CLOUD_CATALOGS.length; i += 1) {
    const catalog = CLOUD_CATALOGS[i];
    onProgress?.(catalog.label, i, CLOUD_CATALOGS.length);
    const temporaryUri = `${directory}${catalog.id}.download.tmp`;
    let finalUri = `${directory}${catalog.id}.catalog.json.gz`;
    let movedToFinal = false;
    try {
      await FileSystem.deleteAsync(temporaryUri, { idempotent: true });
      const response = await FileSystem.downloadAsync(`${CLOUD_BASE}${catalog.path}`, temporaryUri);
      if (response.status < 200 || response.status >= 300) {
        throw new Error(`استجابة الخادم HTTP ${response.status}`);
      }
      const info = await FileSystem.getInfoAsync(temporaryUri, { size: true });
      if (!info.exists || !('size' in info) || info.size <= 20) throw new Error('الملف غير موجود أو حجمه غير صالح.');
      if (info.size > 25 * 1024 * 1024) throw new Error('حجم الفهرس المضغوط أكبر من الحد الآمن المسموح (25 ميجابايت).');

      const base64 = await FileSystem.readAsStringAsync(temporaryUri, { encoding: FileSystem.EncodingType.Base64 });
      const bytes = toByteArray(base64);
      const digest = sha256(bytes);
      const decoded = ungzip(bytes, { to: 'string' });
      if (decoded.length > 100 * 1024 * 1024) throw new Error('حجم المحتوى بعد فك الضغط أكبر من الحد الآمن (100 ميجابايت).');
      const parsed: unknown = JSON.parse(decoded);
      if (!parsed || (typeof parsed !== 'object' && !Array.isArray(parsed))) {
        throw new Error('محتوى الفهرس ليس بنية JSON صالحة.');
      }

      finalUri = `${directory}${catalog.id}.${digest.slice(0, 12)}.catalog.json.gz`;
      await FileSystem.moveAsync({ from: temporaryUri, to: finalUri });
      movedToFinal = true;
      const previous = await db.getFirstAsync<{ local_uri: string }>('SELECT local_uri FROM cloud_staged_files WHERE id=?', catalog.id);
      await db.runAsync(
        `INSERT INTO cloud_staged_files(id,label,local_uri,bytes,sha256,status,downloaded_at)
         VALUES(?,?,?,?,?,'verified_staged',CURRENT_TIMESTAMP)
         ON CONFLICT(id) DO UPDATE SET label=excluded.label, local_uri=excluded.local_uri,
         bytes=excluded.bytes, sha256=excluded.sha256, status='verified_staged', downloaded_at=CURRENT_TIMESTAMP`,
        catalog.id, catalog.label, finalUri, info.size, digest
      );
      if (previous?.local_uri && previous.local_uri !== finalUri) {
        await FileSystem.deleteAsync(previous.local_uri, { idempotent: true }).catch(() => undefined);
      }
      saved.push({ id: catalog.id, label: catalog.label, localUri: finalUri, bytes: info.size, sha256: digest, status: 'verified_staged', downloadedAt: new Date().toISOString() });
    } catch (error) {
      await FileSystem.deleteAsync(temporaryUri, { idempotent: true }).catch(() => undefined);
      if (movedToFinal) await FileSystem.deleteAsync(finalUri, { idempotent: true }).catch(() => undefined);
      failures.push(`${catalog.label}: ${String(error)}`);
    }
  }
  onProgress?.('اكتمل فحص الملفات السحابية', CLOUD_CATALOGS.length, CLOUD_CATALOGS.length);
  if (saved.length === 0) throw new Error(`لم يتم تنزيل أي فهرس. ${failures.join(' | ')}`);
  if (failures.length) throw new Error(`تم حفظ ${saved.length} فهرس منفصلاً بعد التحقق، وتعذر تنزيل بعض الملفات: ${failures.join(' | ')}`);
  return saved;
}


export async function inspectStagedCloudFile(id: string): Promise<{ label: string; bytes: number; sha256: string; rootType: string; keys: string[]; arrayCounts: string[] }> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ label: string; local_uri: string; bytes: number; sha256: string }>(
    'SELECT label, local_uri, bytes, sha256 FROM cloud_staged_files WHERE id=? AND status=\'verified_staged\'', id
  );
  if (!row) throw new Error('لم يتم العثور على الفهرس المحفوظ.');
  const info = await FileSystem.getInfoAsync(row.local_uri);
  if (!info.exists || !info.size || info.size !== row.bytes) throw new Error('الملف المحفوظ غير موجود أو تغير حجمه.');
  const base64 = await FileSystem.readAsStringAsync(row.local_uri, { encoding: FileSystem.EncodingType.Base64 });
  const bytes = toByteArray(base64);
  if (sha256(bytes) !== row.sha256) throw new Error('فشل التحقق من بصمة الملف المحفوظ.');
  const decoded = ungzip(bytes, { to: 'string' });
  if (decoded.length > 100 * 1024 * 1024) throw new Error('حجم الفهرس بعد فك الضغط يتجاوز الحد الآمن للمعاينة.');
  const parsed: unknown = JSON.parse(decoded);
  const isArray = Array.isArray(parsed);
  const object = parsed && typeof parsed === 'object' && !isArray ? parsed as Record<string, unknown> : null;
  const keys = object ? Object.keys(object).slice(0, 30) : [];
  const arrayCounts = object ? Object.entries(object).filter(([, value]) => Array.isArray(value)).map(([key, value]) => `${key}: ${(value as unknown[]).length.toLocaleString('ar-EG')}`).slice(0, 20) : [];
  return { label: row.label, bytes: row.bytes, sha256: row.sha256, rootType: isArray ? `مصفوفة (${parsed.length.toLocaleString('ar-EG')} عنصر)` : object ? 'كائن JSON' : typeof parsed, keys, arrayCounts };
}

export async function removeStagedCloudFile(id: string) {
  const db = await getDb();
  const row = await db.getFirstAsync<{ local_uri: string }>('SELECT local_uri FROM cloud_staged_files WHERE id=?', id);
  if (row?.local_uri) await FileSystem.deleteAsync(row.local_uri, { idempotent: true });
  await db.runAsync('DELETE FROM cloud_staged_files WHERE id=?', id);
}
