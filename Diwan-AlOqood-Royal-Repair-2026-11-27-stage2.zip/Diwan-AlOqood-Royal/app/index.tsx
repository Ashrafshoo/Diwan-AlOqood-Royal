import React, { useEffect, useRef, useState } from 'react';
import { Alert, BackHandler, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, View, Pressable, ActivityIndicator } from 'react-native';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import { SectionTile } from '../src/components/SectionTile';
import { getDb, initializeDatabase } from '../src/database/db';
import { getLegalRecord, listLegalRecords, listLegalSections, searchLegalRecords } from '../src/legal/search';
import { importExtractedDataArchive, importPackageArchives, selectPackageArchives, type PickedArchive } from '../src/importer/importService';
import { downloadCloudCatalogs, inspectStagedCloudFile, listStagedCloudFiles, removeStagedCloudFile, type StagedCloudFile } from '../src/importer/cloudStaging';

type Screen = 'home' | 'search' | 'data' | 'library' | 'encyclopedia' | 'contracts' | 'contractEditor' | 'detail' | 'cloud' | 'cloudLibrary';
type SearchRecord = { record_id: string; section: string; title: string; body?: string | null; metadata_json?: string };
type SectionRow = { section: string; count: number };

const sections: { title: string; subtitle: string; screen: Screen }[] = [
  { title: 'المكتبة القانونية', subtitle: 'القوانين والأحكام والقرارات', screen: 'library' },
  { title: 'موسوعة ديوان القانونية', subtitle: 'الموضوعات والتصنيفات القانونية', screen: 'encyclopedia' },
  { title: 'العقود والنماذج', subtitle: 'نماذج وصيغ قانونية قابلة للتحرير', screen: 'contracts' },
  { title: 'البحث القانوني', subtitle: 'البحث في المحتوى المحلي بعد استيراده', screen: 'search' },
  { title: 'إدارة البيانات', subtitle: 'استيراد الحزم والنسخ الاحتياطي', screen: 'data' },
];

export default function HomeScreen() {
  const [fontsLoaded] = useFonts({ Cairo: require('../assets/fonts/Cairo-Regular.ttf'), CairoBold: require('../assets/fonts/Cairo-Bold.ttf'), ElMessiri: require('../assets/fonts/ElMessiri-Regular.ttf') });
  const [screen, setScreen] = useState<Screen>('home');
  const navigationHistory = useRef<Screen[]>([]);
  const [cloudChecking, setCloudChecking] = useState(false);
  const [cloudMessage, setCloudMessage] = useState('لم يتم الاتصال بالمصدر السحابي بعد.');
  const [cloudFiles, setCloudFiles] = useState<StagedCloudFile[]>([]);
  const [cloudDownloading, setCloudDownloading] = useState(false);
  const [cloudProgress, setCloudProgress] = useState('لم يبدأ التنزيل بعد.');

  function navigate(next: Screen) {
    if (next === screen) return;
    navigationHistory.current.push(screen);
    setScreen(next);
  }

  function goBack() {
    const previous = navigationHistory.current.pop();
    setScreen(previous ?? 'home');
    return true;
  }
  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchRecord[]>([]);
  const [searching, setSearching] = useState(false);
  const [archives, setArchives] = useState<PickedArchive[]>([]);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState({ stage: '', done: 0, total: 0 });
  const [importMessage, setImportMessage] = useState('لم يتم استيراد البيانات بعد.');
  const [sectionsList, setSectionsList] = useState<SectionRow[]>([]);
  const [activeSection, setActiveSection] = useState('');
  const [detail, setDetail] = useState<SearchRecord | null>(null);
  const [drafts, setDrafts] = useState<Array<{id:string;title:string;party_one:string;party_two:string;body:string;updated_at:string}>>([]);
  const [draftId, setDraftId] = useState<string | null>(null);
  const [draftTitle, setDraftTitle] = useState('');
  const [partyOne, setPartyOne] = useState('');
  const [partyTwo, setPartyTwo] = useState('');
  const [draftBody, setDraftBody] = useState('');
  const [savingDraft, setSavingDraft] = useState(false);

  async function refreshDrafts() {
    try {
      const db = await getDb();
      const rows = await db.getAllAsync<{id:string;title:string;party_one:string;party_two:string;body:string;updated_at:string}>(
        'SELECT id,title,party_one,party_two,body,updated_at FROM contract_drafts ORDER BY updated_at DESC'
      );
      setDrafts(rows);
    } catch (error) { Alert.alert('تعذر قراءة المسودات', String(error)); }
  }

  async function saveContractDraft() {
    if (!draftTitle.trim()) { Alert.alert('بيانات ناقصة', 'اكتب عنواناً للمسودة قبل الحفظ.'); return; }
    setSavingDraft(true);
    try {
      const db = await getDb();
      const id = draftId ?? `draft-${Date.now()}`;
      await db.runAsync(
        `INSERT INTO contract_drafts(id,title,party_one,party_two,body,updated_at)
         VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
         ON CONFLICT(id) DO UPDATE SET title=excluded.title,party_one=excluded.party_one,
         party_two=excluded.party_two,body=excluded.body,updated_at=CURRENT_TIMESTAMP`,
        id, draftTitle.trim(), partyOne.trim(), partyTwo.trim(), draftBody,
      );
      setDraftId(id);
      await refreshDrafts();
      Alert.alert('تم الحفظ', 'حُفظت المسودة على هذا الجهاز ويمكنك الرجوع إليها وتعديلها.');
      navigationHistory.current.pop();
      setScreen('contracts');
    } catch (error) { Alert.alert('تعذر حفظ المسودة', String(error)); }
    finally { setSavingDraft(false); }
  }

  async function refreshCloudFiles() {
    try { setCloudFiles(await listStagedCloudFiles()); }
    catch (error) { Alert.alert('تعذر قراءة الملفات المحفوظة', String(error)); }
  }

  async function startCloudCatalogDownload() {
    setCloudDownloading(true);
    setCloudProgress('جارٍ الاتصال وتنزيل الفهارس...');
    try {
      await downloadCloudCatalogs((label, done, total) => setCloudProgress(`${label} · ${done}/${total}`));
      await refreshCloudFiles();
      Alert.alert('انتهى التنزيل', 'تم حفظ الفهارس التي اجتازت فحص GZIP وJSON في مساحة منفصلة. لم يتم دمجها أو تغيير المكتبة الحالية.');
    } catch (error) {
      await refreshCloudFiles();
      Alert.alert('نتيجة التنزيل', String(error));
    } finally { setCloudDownloading(false); }
  }

  useEffect(() => {
    const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
      if (screen !== 'home') return goBack();
      return false;
    });
    return () => subscription.remove();
  }, [screen]);

  useEffect(() => {
    initializeDatabase().then(async () => {
      setReady(true);
      const groups = await listLegalSections();
      setSectionsList(groups);
      const db = await getDb();
      const state = await db.getFirstAsync<{status:string; imported_parts:number; total_parts:number}>('SELECT status, imported_parts, total_parts FROM import_state ORDER BY updated_at DESC LIMIT 1');
      if (state?.status === 'complete') setImportMessage(`البيانات مستوردة وجاهزة للعرض والبحث. الأجزاء: ${state.imported_parts}/${state.total_parts}.`);
      else if (state?.status === 'failed') setImportMessage('تعثر استيراد سابق. أعد اختيار الحزمة نفسها لاستكمال الملفات التي تم التحقق منها.');
    }).catch(e => Alert.alert('خطأ في قاعدة البيانات', String(e)));
  }, []);

  async function runSearch() {
    if (!query.trim()) { setResults([]); return; }
    setSearching(true);
    try {
      const rows = await searchLegalRecords(query) as SearchRecord[];
      setResults(rows);
      if (rows.length === 0) Alert.alert('لا توجد نتائج', 'لم يتم العثور على نتائج. تأكد من اكتمال استيراد البيانات.');
    } catch (e) { Alert.alert('تعذر البحث', String(e)); }
    finally { setSearching(false); }
  }

  async function choosePackages() {
    try {
      const result = await selectPackageArchives();
      if (result.canceled) return;
      const files = (result.assets ?? []).map(file => ({ uri: file.uri, name: file.name }));
      setArchives(files);
      setImportMessage(files.length === 1 ? `تم اختيار حزمة واحدة: ${files[0].name}` : `تم اختيار ${files.length} ملفات ZIP مرقمة.`);
    } catch (e) { Alert.alert('تعذر اختيار الملفات', String(e)); }
  }

  async function startImport() {
    if (archives.length !== 1 && archives.length !== 4) {
      Alert.alert('عدد الملفات غير مناسب', 'اختر حزمة البيانات الواحدة، أو الأجزاء الأربعة المرقمة معاً.');
      return;
    }
    setImporting(true);
    setProgress({ stage: 'بدء الفحص', done: 0, total: 0 });
    try {
      const result = archives.length === 1
        ? await importExtractedDataArchive(archives[0], (stage, done, total) => setProgress({ stage, done, total }))
        : await importPackageArchives(archives, (stage, done, total) => setProgress({ stage, done, total }));
      setImportMessage(result.alreadyImported ? 'هذه البيانات مستوردة بالفعل ولا تحتاج إلى تكرار.' : `اكتمل استيراد وفهرسة ${result.documents} ملف بيانات بنجاح.`);
      const groups = await listLegalSections();
      setSectionsList(groups);
      Alert.alert('اكتمل الاستيراد', result.alreadyImported ? 'البيانات موجودة بالفعل.' : `تم التحقق من ${result.files} ملف وحفظها محلياً.`);
    } catch (e) {
      setImportMessage('لم يتم اعتماد الحزمة. يمكنك إعادة المحاولة بعد معالجة سبب الخطأ.');
      Alert.alert('تعذر إكمال الاستيراد', String(e));
    } finally { setImporting(false); }
  }

  async function openSection(section: string, destination: 'library' | 'encyclopedia') {
    setActiveSection(section);
    try {
      const rows = await listLegalRecords(section, 100, 0) as SearchRecord[];
      setResults(rows);
      navigate(destination);
    } catch (e) { Alert.alert('تعذر عرض القسم', String(e)); }
  }

  async function openDetail(recordId: string) {
    const row = await getLegalRecord(recordId) as SearchRecord | null;
    if (row) { setDetail(row); navigate('detail'); }
  }

  const title = screen === 'home' ? 'ديوان العقود الملكي' : screen === 'search' ? 'البحث القانوني' : screen === 'data' ? 'إدارة البيانات' : screen === 'library' ? 'المكتبة القانونية' : screen === 'encyclopedia' ? 'موسوعة ديوان القانونية' : screen === 'contracts' ? 'العقود والنماذج' : screen === 'contractEditor' ? 'محرر مسودة العقد' : screen === 'cloud' ? 'الارتباط السحابي' : screen === 'cloudLibrary' ? 'مركز تنزيل المكتبة' : 'تفاصيل المحتوى';

  if (!fontsLoaded) return <SafeAreaView style={styles.safe}><View style={styles.loading}><ActivityIndicator size="large"/><Text style={styles.note}>جارٍ تحميل الخطوط العربية...</Text></View></SafeAreaView>;

  return <SafeAreaView style={styles.safe}>
    <ExpoStatusBar style="light"/><StatusBar backgroundColor="#182438"/>
    <View style={styles.header}>
      {screen !== 'home' && <Pressable onPress={goBack} style={styles.back}><Text style={styles.backText}>رجوع ←</Text></Pressable>}
      <Text style={styles.brand}>{title}</Text>
      <Text style={styles.tagline}>موسوعة ومكتبة قانونية · تشغيل محلي مباشر</Text>
    </View>
    <ScrollView contentContainerStyle={styles.content}>
      {screen === 'home' && <>
        <Text style={styles.heading}>مرحباً بك</Text>
        <Text style={styles.note}>يفتح التطبيق مباشرة دون حساب أو كلمة مرور أو بريد إلكتروني أو اشتراك أو دفع.</Text>
        {!ready && <View style={styles.loading}><ActivityIndicator/><Text style={styles.note}>جارٍ تجهيز قاعدة البيانات المحلية...</Text></View>}
        {sections.map(item => <SectionTile key={item.screen} title={item.title} subtitle={item.subtitle} onPress={() => { setResults([]); setActiveSection(''); if (item.screen === 'contracts') refreshDrafts(); navigate(item.screen); }}/>)}
        <Pressable style={styles.cloudTile} onPress={() => navigate('cloud')}><Text style={styles.cloudTileTitle}>الارتباط السحابي وتحديث المكتبة</Text><Text style={styles.cloudTileSub}>التحقق من مصدر المكتبة الأصلي</Text></Pressable>
        <Text style={styles.footer}>نسخة إعادة البناء · بيانات محلية</Text>
      </>}
      {screen === 'search' && <>
        <Text style={styles.heading}>ابحث في المحتوى القانوني</Text>
        <TextInput value={query} onChangeText={setQuery} placeholder="اكتب كلمة أو عبارة للبحث" placeholderTextColor="#858b95" style={styles.input} textAlign="right" returnKeyType="search" onSubmitEditing={runSearch}/>
        <Pressable style={styles.primary} onPress={runSearch} disabled={searching}>{searching ? <ActivityIndicator color="#fff"/> : <Text style={styles.primaryText}>بحث</Text>}</Pressable>
        {results.map(row => <Pressable key={row.record_id} onPress={() => openDetail(row.record_id)} style={styles.result}><Text style={styles.resultTitle}>{row.title}</Text><Text style={styles.resultMeta}>{row.section}</Text>{row.body ? <Text style={styles.resultBody}>{row.body.slice(0,350)}</Text> : null}</Pressable>)}
        {results.length === 0 && <Text style={styles.note}>ستظهر النتائج بعد اكتمال استيراد البيانات وفهرستها.</Text>}
      </>}
      {screen === 'data' && <>
        <Text style={styles.heading}>استيراد حزم البيانات الأصلية</Text>
        <Text style={styles.note}>يمكنك اختيار حزمة البيانات المستخرجة الواحدة، أو الأجزاء الأربعة المرقمة معاً. يفحص التطبيق سلامة ZIP وملفات JSON، ويحفظ نسخة المصدر مضغوطة، ويستكمل الملفات التي تم استيرادها عند إعادة المحاولة.</Text>
        <Pressable style={styles.primary} onPress={choosePackages} disabled={importing}><Text style={styles.primaryText}>اختيار حزمة واحدة أو أربعة أجزاء ZIP</Text></Pressable>
        {archives.map((file, i) => <Text key={`${file.name}-${i}`} style={styles.fileName}>✓ {file.name}</Text>)}
        <Pressable style={[styles.primary, archives.length !== 1 && archives.length !== 4 && styles.disabled]} onPress={startImport} disabled={importing || (archives.length !== 1 && archives.length !== 4)}>
          {importing ? <ActivityIndicator color="#fff"/> : <Text style={styles.primaryText}>بدء التحقق والاستيراد</Text>}
        </Pressable>
        {importing && <View style={styles.progress}><Text style={styles.progressText}>{progress.stage} · {progress.done}/{progress.total}</Text><View style={styles.track}><View style={[styles.fill,{width:`${progress.total ? Math.min(100,progress.done/progress.total*100) : 0}%`}]}/></View></View>}
        <View style={styles.info}><Text style={styles.infoTitle}>حالة البيانات</Text><Text style={styles.infoText}>{importMessage}</Text></View>
      </>}
      {(screen === 'library' || screen === 'encyclopedia') && <>
        <Text style={styles.heading}>{activeSection || 'أقسام المحتوى المتاح'}</Text>
        {results.length > 0 && results.map(row => <Pressable key={row.record_id} onPress={() => openDetail(row.record_id)} style={styles.result}><Text style={styles.resultTitle}>{row.title}</Text><Text style={styles.resultMeta}>{row.section}</Text>{row.body ? <Text style={styles.resultBody}>{row.body.slice(0,260)}</Text> : null}</Pressable>)}
        {results.length === 0 && sectionsList.filter(s => screen === 'encyclopedia' ? s.section.includes('الموسوعة') : !s.section.includes('الموسوعة')).map(item => <Pressable key={item.section} style={styles.result} onPress={() => openSection(item.section, screen)}><Text style={styles.resultTitle}>{item.section}</Text><Text style={styles.resultMeta}>{item.count.toLocaleString('ar-EG')} سجل</Text></Pressable>)}
        {sectionsList.length === 0 && <Text style={styles.note}>لا توجد بيانات مفعّلة للعرض بعد. استورد الأجزاء الأربعة أولاً.</Text>}
      </>}
      {screen === 'cloud' && <>
        <Text style={styles.heading}>الارتباط السحابي وتحديث المكتبة</Text>
        <Text style={styles.note}>تم العثور داخل التطبيق الأصلي على مصدر المكتبة: diwan-contracts.vercel.app، ومسارات لملفات فهرسة المكتبة القانونية والموسوعة. لن يتم استبدال أي بيانات محلية قبل التحقق من إصدار الحزمة وبصمات الملفات واكتمال التنزيل.</Text>
        <Pressable style={styles.primary} onPress={async () => {
          setCloudChecking(true);
          setCloudMessage('جارٍ اختبار الاتصال بالمصدر السحابي...');
          try {
            const response = await fetch('https://diwan-contracts.vercel.app/', { method: 'GET' });
            if (response.ok) setCloudMessage('المصدر السحابي يستجيب. لكن لم يتم العثور بعد على ملف بيان تحديث موثوق يحدد إصدار المكتبة وبصماتها؛ لذلك لم يتم تنزيل أو تغيير أي بيانات.');
            else setCloudMessage(`المصدر السحابي أعاد حالة HTTP ${response.status}. لم يتم تغيير البيانات المحلية.`);
          } catch (error) {
            setCloudMessage(`تعذر الاتصال بالمصدر السحابي: ${String(error)}. بياناتك المحلية لم تتأثر.`);
          } finally { setCloudChecking(false); }
        }} disabled={cloudChecking}>{cloudChecking ? <ActivityIndicator color="#fff"/> : <Text style={styles.primaryText}>التحقق من الاتصال والتحديثات</Text>}</Pressable>
        <View style={styles.info}><Text style={styles.infoTitle}>نتيجة التحقق</Text><Text style={styles.infoText}>{cloudMessage}</Text></View>
        <Pressable style={styles.secondary} onPress={() => { navigate('cloudLibrary'); refreshCloudFiles(); }}><Text style={styles.secondaryText}>فتح مركز تنزيل المكتبة السحابية</Text></Pressable>
        <Text style={styles.note}>يمكن تنزيل الفهارس إلى مساحة منفصلة أولاً، ثم مراجعتها قبل أي دمج أو تحديث. لا يتم استبدال المكتبة المحلية تلقائياً.</Text>
      </>}
      {screen === 'cloudLibrary' && <>
        <Text style={styles.heading}>مركز تنزيل المكتبة السحابية</Text>
        <Text style={styles.note}>هذا قسم مستقل لتنزيل فهارس المكتبة الأصلية من مسارات ظهرت داخل التطبيق الأصلي. تُحفظ الملفات في مساحة مؤقتة داخل التطبيق بعد التحقق من استجابة الخادم وسلامة GZIP وصحة JSON وبصمة SHA-256. التنزيل لا يدمج ولا يستبدل أي محتوى محلي.</Text>
        <Pressable style={styles.primary} onPress={startCloudCatalogDownload} disabled={cloudDownloading}>
          {cloudDownloading ? <ActivityIndicator color="#fff"/> : <Text style={styles.primaryText}>تنزيل فهارس المكتبة السحابية</Text>}
        </Pressable>
        <Text style={styles.progressText}>{cloudProgress}</Text>
        <Pressable style={styles.secondary} onPress={refreshCloudFiles}><Text style={styles.secondaryText}>تحديث قائمة الملفات المحفوظة</Text></Pressable>
        <View style={styles.info}><Text style={styles.infoTitle}>الملفات المحفوظة منفصلة</Text><Text style={styles.infoText}>عدد الفهارس: {cloudFiles.length}</Text></View>
        {cloudFiles.map(file => <View key={file.id} style={styles.result}>
          <Text style={styles.resultTitle}>{file.label}</Text>
          <Text style={styles.resultMeta}>تم التحقق والحفظ منفصلاً · {(file.bytes / 1024).toFixed(1)} كيلوبايت</Text>
          <Text style={styles.resultBody}>SHA-256: {file.sha256}</Text>
          <Text style={styles.stagedBadge}>جاهز للمراجعة اللاحقة — غير مدمج</Text>
          <Pressable style={styles.secondary} onPress={async () => { try { const detail = await inspectStagedCloudFile(file.id); const content = [`نوع البيانات: ${detail.rootType}`, `مفاتيح الفهرس: ${detail.keys.join('، ') || 'لا توجد مفاتيح علوية'}`, `المصفوفات: ${detail.arrayCounts.join('، ') || 'لم تُكتشف مصفوفات مباشرة'}`, `الحجم: ${(detail.bytes / 1024).toFixed(1)} كيلوبايت`, `SHA-256: ${detail.sha256}`].join('\n'); Alert.alert(detail.label, content); } catch (error) { Alert.alert('تعذرت معاينة الفهرس', String(error)); } }}>
            <Text style={styles.secondaryText}>معاينة بنية الفهرس</Text>
          </Pressable>
          <Pressable style={styles.secondary} onPress={() => Alert.alert('حذف النسخة السحابية المؤقتة؟', 'سيتم حذف هذا الفهرس من مساحة التنزيل المنفصلة فقط، ولن تتأثر المكتبة المحلية.', [{ text: 'إلغاء', style: 'cancel' }, { text: 'حذف', style: 'destructive', onPress: async () => { try { await removeStagedCloudFile(file.id); await refreshCloudFiles(); } catch (error) { Alert.alert('تعذر الحذف', String(error)); } } }])}>
            <Text style={styles.secondaryText}>حذف النسخة المؤقتة</Text>
          </Pressable>
        </View>)}
        {cloudFiles.length === 0 && <Text style={styles.note}>لا توجد ملفات سحابية محفوظة بعد. استخدم زر التنزيل أعلاه.</Text>}
        <Text style={styles.note}>ملاحظة مهمة: هذه المرحلة تحفظ الفهارس فقط. لن ندمجها قبل استعادة صيغة ملفات المحتوى التابعة لها وقواعد المطابقة والإصدارات، حتى لا تتكرر السجلات أو تُحذف بيانات موجودة.</Text>
      </>}
      {screen === 'contracts' && <>
        <Text style={styles.heading}>العقود والنماذج</Text>
        <Text style={styles.note}>مساحة عمل محلية لإنشاء مسوداتك وحفظها وتعديلها. لم نثبت بعد استعادة مكتبة القوالب الأصلية كاملة، لذلك لا ننسب أي نموذج غير مستخرج إلى التطبيق.</Text>
        <Pressable style={styles.primary} onPress={() => { setDraftId(null); setDraftTitle(''); setPartyOne(''); setPartyTwo(''); setDraftBody(''); navigate('contractEditor'); }}><Text style={styles.primaryText}>إنشاء مسودة عقد جديدة</Text></Pressable>
        <Text style={styles.infoTitle}>المسودات المحفوظة ({drafts.length})</Text>
        {drafts.map(draft => <Pressable key={draft.id} style={styles.result} onPress={() => { setDraftId(draft.id); setDraftTitle(draft.title); setPartyOne(draft.party_one); setPartyTwo(draft.party_two); setDraftBody(draft.body); navigate('contractEditor'); }}><Text style={styles.resultTitle}>{draft.title}</Text><Text style={styles.resultMeta}>آخر تعديل: {draft.updated_at}</Text><Text style={styles.resultBody}>الطرف الأول: {draft.party_one || 'غير محدد'} · الطرف الثاني: {draft.party_two || 'غير محدد'}</Text></Pressable>)}
        {drafts.length === 0 && <Text style={styles.note}>لا توجد مسودات محفوظة بعد. أنشئ مسودة لتبدأ في كتابة بيانات العقد وبنوده.</Text>}
      </>}
      {screen === 'contractEditor' && <>
        <Text style={styles.heading}>محرر مسودة العقد</Text>
        <Text style={styles.note}>هذه مسودة تحريرية محلية وليست نموذجاً قانونياً معتمداً. راجع الصياغة والبيانات قبل استخدامها أو توقيعها.</Text>
        <Text style={styles.fieldLabel}>عنوان العقد</Text><TextInput value={draftTitle} onChangeText={setDraftTitle} placeholder="مثال: عقد بيع" placeholderTextColor="#858b95" style={styles.input} textAlign="right" />
        <Text style={styles.fieldLabel}>الطرف الأول</Text><TextInput value={partyOne} onChangeText={setPartyOne} placeholder="الاسم والصفة والبيانات" placeholderTextColor="#858b95" style={styles.input} textAlign="right" />
        <Text style={styles.fieldLabel}>الطرف الثاني</Text><TextInput value={partyTwo} onChangeText={setPartyTwo} placeholder="الاسم والصفة والبيانات" placeholderTextColor="#858b95" style={styles.input} textAlign="right" />
        <Text style={styles.fieldLabel}>موضوع العقد والبنود</Text><TextInput value={draftBody} onChangeText={setDraftBody} placeholder="اكتب نص المسودة وبنودها هنا..." placeholderTextColor="#858b95" style={[styles.input, styles.multiline]} textAlign="right" multiline textAlignVertical="top" />
        <Pressable style={styles.primary} onPress={saveContractDraft} disabled={savingDraft}>{savingDraft ? <ActivityIndicator color="#fff"/> : <Text style={styles.primaryText}>حفظ المسودة</Text>}</Pressable>
      </>}
      {screen === 'detail' && detail && <>
        <Text style={styles.heading}>{detail.title}</Text>
        <Text style={styles.resultMeta}>{detail.section}</Text>
        <Text style={styles.detailBody}>{detail.body || 'لا يتضمن سجل الفهرس نصاً كاملاً ضمن هذه البيانات.'}</Text>
        <Text style={styles.note}>تنبيه: بعض السجلات الأصلية موسومة بأنها تحتاج إلى مراجعة قانونية؛ يرجى الرجوع إلى المصدر الرسمي قبل الاعتماد عليها.</Text>
      </>}
    </ScrollView>
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:'#f5f3ef'}, header:{backgroundColor:'#182438',paddingHorizontal:22,paddingTop:18,paddingBottom:22,alignItems:'flex-end'}, brand:{fontFamily:'ElMessiri',fontSize:24,fontWeight:'800',color:'#fff',textAlign:'right'}, tagline:{fontFamily:'Cairo',fontSize:12,color:'#d9c9a8',marginTop:7,textAlign:'right'}, back:{alignSelf:'flex-start',paddingVertical:5,marginBottom:10}, backText:{fontFamily:'Cairo',color:'#e4d2ae',fontSize:13}, content:{padding:18}, heading:{fontFamily:'CairoBold',fontSize:21,fontWeight:'700',color:'#202d42',textAlign:'right',marginBottom:8}, note:{fontFamily:'Cairo',fontSize:13,color:'#697384',textAlign:'right',lineHeight:22,marginBottom:14}, secondary:{backgroundColor:'#e6ebf1',padding:13,borderRadius:12,alignItems:'center',marginVertical:8,borderWidth:1,borderColor:'#cbd5e1'},secondaryText:{fontFamily:'CairoBold',color:'#25344a',fontSize:14},stagedBadge:{fontFamily:'CairoBold',fontSize:12,color:'#276749',textAlign:'right',marginTop:8}, cloudTile:{backgroundColor:'#e9eef4',borderWidth:1,borderColor:'#cbd5e1',borderRadius:12,padding:15,marginTop:14},cloudTileTitle:{fontFamily:'CairoBold',fontSize:15,color:'#182438',textAlign:'right'},cloudTileSub:{fontFamily:'Cairo',fontSize:12,color:'#596579',textAlign:'right',marginTop:4},footer:{textAlign:'center',color:'#858585',fontSize:11,marginTop:20,marginBottom:30}, loading:{alignItems:'center',padding:10}, input:{fontFamily:'Cairo',backgroundColor:'#fff',borderWidth:1,borderColor:'#d9d3c9',borderRadius:12,padding:14,color:'#202d42',marginVertical:10}, primary:{backgroundColor:'#182438',padding:15,borderRadius:12,alignItems:'center',marginVertical:8}, primaryText:{fontFamily:'CairoBold',color:'#fff',fontWeight:'700',fontSize:15}, disabled:{opacity:0.45}, result:{backgroundColor:'#fff',padding:14,borderRadius:12,marginVertical:6,borderWidth:1,borderColor:'#e8e1d5'}, resultTitle:{fontFamily:'CairoBold',fontSize:16,fontWeight:'700',color:'#273449',textAlign:'right'}, resultMeta:{fontFamily:'Cairo',fontSize:11,color:'#a78243',textAlign:'right',marginTop:5}, resultBody:{fontFamily:'Cairo',fontSize:13,color:'#505967',textAlign:'right',marginTop:8,lineHeight:21}, fileName:{fontFamily:'Cairo',fontSize:12,color:'#3d4654',textAlign:'right',paddingVertical:5}, fieldLabel:{fontFamily:'CairoBold',fontSize:13,color:'#273449',textAlign:'right',marginTop:8}, multiline:{minHeight:190,textAlignVertical:'top'}, info:{backgroundColor:'#eef3f7',borderRadius:12,padding:14,marginTop:16}, infoTitle:{fontFamily:'CairoBold',fontWeight:'700',color:'#273449',textAlign:'right'}, infoText:{fontFamily:'Cairo',fontSize:12,color:'#4b596b',textAlign:'right',lineHeight:20,marginTop:6}, progress:{marginTop:12}, progressText:{fontFamily:'Cairo',fontSize:12,color:'#39465a',textAlign:'right'}, track:{height:9,backgroundColor:'#dce2e9',borderRadius:9,overflow:'hidden',marginTop:8}, fill:{height:9,backgroundColor:'#397a61'}, detailBody:{fontFamily:'Cairo',fontSize:15,color:'#303b4d',textAlign:'right',lineHeight:28,marginTop:18,marginBottom:20}
});
