#!/usr/bin/env python3
"""Deep verification of the four Diwan data archives and every GZIP/JSON payload."""
import gzip, hashlib, json, pathlib, sys, zipfile

root = pathlib.Path(__file__).resolve().parents[1]
base = root / 'data_packages'
manifest_path = base / 'all-parts-manifest.json'
if not manifest_path.exists():
    print(f'Missing master manifest: {manifest_path}', file=sys.stderr)
    sys.exit(2)
master = json.loads(manifest_path.read_text(encoding='utf-8'))
errors = []
seen = set()
count = 0
uncompressed = 0
for number in range(1, master['partsTotal'] + 1):
    archive = base / f"Diwan_Data_Part_{number}_of_{master['partsTotal']}.zip"
    if not archive.exists():
        errors.append(f'missing archive: {archive.name}')
        continue
    try:
        with zipfile.ZipFile(archive) as z:
            bad = z.testzip()
            if bad:
                errors.append(f'ZIP CRC failure {archive.name}: {bad}')
                continue
            names = set(z.namelist())
            for required in ('package-manifest.json', 'all-parts-manifest.json'):
                if required not in names:
                    errors.append(f'{required} missing from {archive.name}')
            part = json.loads(z.read('package-manifest.json'))
            other_master = json.loads(z.read('all-parts-manifest.json'))
            if other_master != master:
                errors.append(f'master manifest mismatch: {archive.name}')
            if part.get('partNumber') != number or part.get('partsTotal') != master['partsTotal']:
                errors.append(f'part number mismatch: {archive.name}')
            if part.get('filesCount') != len(part.get('files', [])):
                errors.append(f'file count mismatch: {archive.name}')
            for item in part.get('files', []):
                path = item['path']
                if path in seen:
                    errors.append(f'duplicate data path: {path}')
                    continue
                seen.add(path)
                if path not in names:
                    errors.append(f'missing payload {path} in {archive.name}')
                    continue
                raw_gzip = z.read(path)
                if len(raw_gzip) != item['compressedBytes']:
                    errors.append(f'compressed byte length mismatch: {path}')
                    continue
                if hashlib.sha256(raw_gzip).hexdigest() != item['sha256']:
                    errors.append(f'compressed SHA-256 mismatch: {path}')
                    continue
                try:
                    raw_json = gzip.decompress(raw_gzip)
                    if len(raw_json) != item['uncompressedBytes']:
                        errors.append(f'uncompressed byte length mismatch: {path}')
                        continue
                    if hashlib.sha256(raw_json).hexdigest() != item['jsonSha256']:
                        errors.append(f'JSON SHA-256 mismatch: {path}')
                        continue
                    json.loads(raw_json)
                except Exception as exc:
                    errors.append(f'GZIP/JSON invalid: {path}: {exc}')
                    continue
                count += 1
                uncompressed += len(raw_json)
    except Exception as exc:
        errors.append(f'cannot read {archive.name}: {exc}')
if count != master['filesTotal']:
    errors.append(f'verified file count mismatch: {count}/{master["filesTotal"]}')
if len(seen) != master['filesTotal']:
    errors.append(f'unique path count mismatch: {len(seen)}/{master["filesTotal"]}')
if uncompressed != master['totalUncompressedBytes']:
    errors.append(f'uncompressed total mismatch: {uncompressed}/{master["totalUncompressedBytes"]}')
print(json.dumps({
    'packageId': master['packageId'], 'parts': master['partsTotal'],
    'verifiedFiles': count, 'uncompressedBytes': uncompressed,
    'errors': errors,
}, ensure_ascii=False, indent=2))
sys.exit(1 if errors else 0)
