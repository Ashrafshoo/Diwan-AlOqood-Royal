#!/usr/bin/env python3
"""Verify the single extracted-data ZIP used by the Android importer."""
import hashlib
import json
import pathlib
import sys
import zipfile

if len(sys.argv) != 2:
    raise SystemExit('Usage: python scripts/verify_extracted_archive.py <archive.zip>')
archive = pathlib.Path(sys.argv[1])
errors = []
verified = 0
bytes_total = 0
try:
    with zipfile.ZipFile(archive) as zf:
        bad = zf.testzip()
        if bad:
            errors.append(f'ZIP CRC failure: {bad}')
        if 'data-import-manifest.json' not in zf.namelist():
            raise ValueError('data-import-manifest.json is missing')
        manifest = json.loads(zf.read('data-import-manifest.json'))
        if manifest.get('format') != 'diwan-extracted-data' or manifest.get('formatVersion') != 1:
            errors.append('Unsupported manifest format')
        entries = manifest.get('files', [])
        if len(entries) != manifest.get('filesTotal'):
            errors.append('Manifest file count mismatch')
        seen = set()
        for item in entries:
            name = item['path']
            if name in seen:
                errors.append(f'Duplicate path: {name}')
                continue
            seen.add(name)
            if name.startswith('/') or '..' in pathlib.PurePosixPath(name).parts or '\\' in name:
                errors.append(f'Unsafe path: {name}')
                continue
            try:
                raw = zf.read(name)
                if len(raw) != item['bytes']:
                    errors.append(f'Size mismatch: {name}')
                    continue
                if hashlib.sha256(raw).hexdigest() != item['sha256']:
                    errors.append(f'SHA-256 mismatch: {name}')
                    continue
                json.loads(raw)
                verified += 1
                bytes_total += len(raw)
            except Exception as exc:
                errors.append(f'Invalid JSON or missing file {name}: {exc}')
        actual = {n for n in zf.namelist() if n.lower().endswith('.json') and n != 'data-import-manifest.json'}
        if actual != seen:
            errors.append(f'Archive/manifest path set mismatch ({len(actual)} vs {len(seen)})')
        if bytes_total != manifest.get('totalBytes'):
            errors.append(f'Total byte mismatch: {bytes_total}/{manifest.get("totalBytes")}')
except Exception as exc:
    errors.append(str(exc))

print(json.dumps({
    'archive': archive.name,
    'verifiedJsonFiles': verified,
    'totalJsonBytes': bytes_total,
    'errors': errors,
}, ensure_ascii=False, indent=2))
sys.exit(1 if errors else 0)
