import { getDb } from '../database/db';
export async function searchLegalRecords(query: string, section?: string) {
  const db = await getDb();
  const q = `%${query.trim()}%`;
  const base = `SELECT r.record_id, r.section, r.title, r.body FROM legal_records r
    INNER JOIN import_state s ON s.package_id = r.package_id AND s.status = 'complete'`;
  if (section) return db.getAllAsync(
    `${base} WHERE r.section = ? AND (r.title LIKE ? OR r.body LIKE ?) ORDER BY r.title LIMIT 100`, section, q, q,
  );
  return db.getAllAsync(
    `${base} WHERE r.title LIKE ? OR r.body LIKE ? ORDER BY r.title LIMIT 100`, q, q,
  );
}

export async function listLegalRecords(section: string, limit = 50, offset = 0) {
  const db = await getDb();
  return db.getAllAsync(
    `SELECT r.record_id, r.section, r.title, r.body FROM legal_records r
     INNER JOIN import_state s ON s.package_id = r.package_id AND s.status = 'complete'
     WHERE r.section LIKE ? ORDER BY r.title LIMIT ? OFFSET ?`, `%${section}%`, limit, offset,
  );
}

export async function getLegalRecord(recordId: string) {
  const db = await getDb();
  return db.getFirstAsync(
    `SELECT r.record_id, r.section, r.title, r.body, r.metadata_json FROM legal_records r
     INNER JOIN import_state s ON s.package_id = r.package_id AND s.status = 'complete'
     WHERE r.record_id = ?`, recordId,
  );
}

export async function listLegalSections() {
  const db = await getDb();
  return db.getAllAsync<{section:string; count:number}>(
    `SELECT r.section, COUNT(*) AS count FROM legal_records r
     INNER JOIN import_state s ON s.package_id = r.package_id AND s.status = 'complete'
     GROUP BY r.section ORDER BY r.section`,
  );
}
