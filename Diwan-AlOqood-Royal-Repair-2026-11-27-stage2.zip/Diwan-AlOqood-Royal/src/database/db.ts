import * as SQLite from 'expo-sqlite';

let dbPromise: Promise<SQLite.SQLiteDatabase> | undefined;
export function getDb() {
  if (!dbPromise) dbPromise = SQLite.openDatabaseAsync('diwan-local.db');
  return dbPromise;
}

export async function initializeDatabase() {
  const db = await getDb();
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 10000;
    CREATE TABLE IF NOT EXISTS imported_files (
      package_id TEXT NOT NULL, path TEXT NOT NULL, sha256 TEXT NOT NULL,
      imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(package_id, path)
    );
    CREATE TABLE IF NOT EXISTS imported_packages (
      package_id TEXT NOT NULL, part_number INTEGER NOT NULL, sha256 TEXT NOT NULL,
      imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY(package_id, part_number)
    );
    CREATE TABLE IF NOT EXISTS import_state (
      package_id TEXT PRIMARY KEY, status TEXT NOT NULL, total_parts INTEGER NOT NULL,
      imported_parts INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS source_documents (
      path TEXT PRIMARY KEY, package_id TEXT NOT NULL, json_sha256 TEXT NOT NULL,
      content_json TEXT NOT NULL DEFAULT '', compressed_gzip BLOB, imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS legal_records (
      record_id TEXT PRIMARY KEY, package_id TEXT NOT NULL DEFAULT '', section TEXT NOT NULL, title TEXT NOT NULL,
      body TEXT, metadata_json TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX IF NOT EXISTS idx_legal_records_title ON legal_records(title);
    CREATE INDEX IF NOT EXISTS idx_legal_records_section ON legal_records(section);
    CREATE TABLE IF NOT EXISTS contract_drafts (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, party_one TEXT NOT NULL DEFAULT '',
      party_two TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_contract_drafts_updated ON contract_drafts(updated_at);
    CREATE TABLE IF NOT EXISTS cloud_staged_files (
      id TEXT PRIMARY KEY, label TEXT NOT NULL, local_uri TEXT NOT NULL, bytes INTEGER NOT NULL,
      sha256 TEXT NOT NULL, status TEXT NOT NULL, downloaded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);
  const columns = await db.getAllAsync<{ name: string }>('PRAGMA table_info(legal_records)');
  if (!columns.some(column => column.name === 'package_id')) {
    await db.execAsync("ALTER TABLE legal_records ADD COLUMN package_id TEXT NOT NULL DEFAULT ''");
  }
  const sourceColumns = await db.getAllAsync<{ name: string }>('PRAGMA table_info(source_documents)');
  if (!sourceColumns.some(column => column.name === 'compressed_gzip')) {
    await db.execAsync('ALTER TABLE source_documents ADD COLUMN compressed_gzip BLOB');
  }
  await db.execAsync('CREATE INDEX IF NOT EXISTS idx_legal_records_package ON legal_records(package_id)');
  return db;
}
