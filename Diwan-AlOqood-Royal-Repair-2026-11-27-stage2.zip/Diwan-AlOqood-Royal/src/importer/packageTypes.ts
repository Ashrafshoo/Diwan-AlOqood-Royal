export type PackageFile = {
  path: string; sha256: string; jsonSha256: string;
  compressedBytes: number; uncompressedBytes: number;
};
export type AllPartsManifest = {
  packageId: string; sourceApp: string; sourceVersion: string;
  partsTotal: number; filesTotal: number; totalCompressedBytes: number;
  totalUncompressedBytes: number; files: PackageFile[];
};
export type PartManifest = {
  format: string; formatVersion: number; packageId: string;
  sourceApp: string; sourceVersion: string; partNumber: number;
  partsTotal: number; filesCount: number; compressedBytes: number;
  uncompressedBytes: number; files: PackageFile[];
};
