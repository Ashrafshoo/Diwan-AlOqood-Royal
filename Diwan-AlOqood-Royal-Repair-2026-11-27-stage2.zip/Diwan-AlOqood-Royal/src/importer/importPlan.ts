import type { AllPartsManifest, PartManifest } from './packageTypes';

export function validatePackageSet(master: AllPartsManifest, parts: PartManifest[]) {
  const errors: string[] = [];
  if (!master?.packageId || !Array.isArray(master.files)) errors.push('بيان الحزمة الرئيسي غير صالح');
  if (master.partsTotal !== parts.length) errors.push(`عدد الأجزاء غير مكتمل: المطلوب ${master.partsTotal} والمحدد ${parts.length}`);
  const seen = new Set<number>();
  const allPaths = new Set<string>();
  for (const part of parts) {
    if (part.format !== 'diwan-data-package' || part.formatVersion !== 1) errors.push('صيغة أحد الأجزاء غير مدعومة');
    if (part.packageId !== master.packageId) errors.push('يوجد جزء تابع لحزمة مختلفة');
    if (part.partsTotal !== master.partsTotal) errors.push('إجمالي الأجزاء غير متطابق');
    if (part.sourceVersion !== master.sourceVersion || part.sourceApp !== master.sourceApp) errors.push('مصدر البيانات أو إصدارها غير متطابق');
    if (part.partNumber < 1 || part.partNumber > master.partsTotal) errors.push('رقم جزء خارج النطاق');
    if (seen.has(part.partNumber)) errors.push(`الجزء رقم ${part.partNumber} مكرر`);
    seen.add(part.partNumber);
    if (!Array.isArray(part.files) || part.files.length !== part.filesCount) errors.push(`قائمة ملفات الجزء ${part.partNumber} غير مكتملة`);
    let compressedSum = 0;
    let uncompressedSum = 0;
    for (const file of part.files ?? []) {
      if (allPaths.has(file.path)) errors.push(`ملف مكرر بين الأجزاء: ${file.path}`);
      allPaths.add(file.path);
      compressedSum += file.compressedBytes;
      uncompressedSum += file.uncompressedBytes;
    }
    if (compressedSum !== part.compressedBytes || uncompressedSum !== part.uncompressedBytes) errors.push(`أحجام بيانات الجزء ${part.partNumber} لا تطابق البيان`);
  }
  for (let i = 1; i <= master.partsTotal; i++) if (!seen.has(i)) errors.push(`الجزء رقم ${i} غير موجود`);
  if (allPaths.size !== master.filesTotal) errors.push(`إجمالي الملفات لا يطابق البيان الرئيسي (${allPaths.size}/${master.filesTotal})`);
  if (master.files.reduce((sum, file) => sum + file.compressedBytes, 0) !== master.totalCompressedBytes) errors.push('إجمالي الحجم المضغوط لا يطابق البيان الرئيسي');
  if (master.files.reduce((sum, file) => sum + file.uncompressedBytes, 0) !== master.totalUncompressedBytes) errors.push('إجمالي الحجم بعد فك الضغط لا يطابق البيان الرئيسي');
  const masterPaths = new Set(master.files.map(f => f.path));
  for (const part of parts) for (const file of part.files ?? []) {
    const masterFile = master.files.find(candidate => candidate.path === file.path);
    if (!masterFile) errors.push(`ملف غير معروف في البيان الرئيسي: ${file.path}`);
    else if (masterFile.sha256 !== file.sha256 || masterFile.jsonSha256 !== file.jsonSha256 || masterFile.compressedBytes !== file.compressedBytes || masterFile.uncompressedBytes !== file.uncompressedBytes) errors.push(`بيانات الملف لا تطابق البيان الرئيسي: ${file.path}`);
  }
  for (const path of allPaths) if (!masterPaths.has(path)) errors.push(`ملف غير معروف في البيان الرئيسي: ${path}`);
  return { ok: errors.length === 0, errors };
}
