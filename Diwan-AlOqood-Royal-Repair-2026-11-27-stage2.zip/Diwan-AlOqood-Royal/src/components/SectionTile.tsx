import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
export function SectionTile({ title, subtitle, onPress }: { title: string; subtitle: string; onPress: () => void }) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={styles.card}>
    <View style={styles.mark} /><View style={styles.copy}>
      <Text style={styles.title}>{title}</Text><Text style={styles.subtitle}>{subtitle}</Text>
    </View><Text style={styles.arrow}>‹</Text>
  </Pressable>;
}
const styles = StyleSheet.create({ card:{ flexDirection:'row-reverse', alignItems:'center', padding:16, marginVertical:6, borderRadius:14, backgroundColor:'#fff', borderWidth:1, borderColor:'#e8e1d5' }, mark:{width:5,height:38,borderRadius:5,backgroundColor:'#a78243'}, copy:{flex:1,alignItems:'flex-end',marginHorizontal:12},title:{fontSize:17,fontWeight:'700',color:'#273449'},subtitle:{fontSize:12,color:'#737b86',marginTop:4},arrow:{fontSize:28,color:'#a78243'} });
