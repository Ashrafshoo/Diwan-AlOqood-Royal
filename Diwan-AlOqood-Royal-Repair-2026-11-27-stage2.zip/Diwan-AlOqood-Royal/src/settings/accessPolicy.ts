/** النسخة الأولى تعمل محلياً دون حساب أو اشتراك أو بوابة دفع. */
export const ACCESS_POLICY = Object.freeze({
  authenticationRequired: false,
  emailRequired: false,
  passwordRequired: false,
  subscriptionRequired: false,
  paymentRequired: false,
  biometricLockEnabled: false,
  adsEnabled: false,
  localDataAvailableOffline: true,
});

export function canOpenAppWithoutAccount(): boolean {
  return !ACCESS_POLICY.authenticationRequired;
}
