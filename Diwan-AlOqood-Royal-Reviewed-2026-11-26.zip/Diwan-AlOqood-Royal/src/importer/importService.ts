import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { unzip } from 'react-native-zip-archive';
import { sha256 } from 'js-sha256';
import { toByteArray } from 'base64-js';
import { ungzip } from 'pako';
import { getDb, initializeDatabase } from '../database/db';
import { validatePackageSet } from './importPlan';
import type { AllPartsManifest, PartManifest, PackageFile } from './packageTypes';

const ROOT = `${FileSystem.documentDirectory}diwan-import/`;
const EXPECTED_MASTER_SHA256 = '75dde1b6be7b7b9b37440444008bfac26853cd006e28449f3d469b65a96adbea';
export type PickedArchive = { uri: string; name: string };
type Progress = (stage: string, done: number, total: number) => void;

export async function selectPackageArchives() {
  return DocumentPicker.getDocumentAsync({
    type: ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'],
    multiple: true, copyToCacheDirectory: true,
  });
}

async function readText(uri: string) {
  return FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.UTF8 });
}

async function readJson<T>(uri: string): Promise<T> {
  return JSON.parse(await readText(uri)) as T;
}

async function readBytes(uri: string): Promise<Uint8Array> {
  const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  return toByteArray(base64);
}

function safePath(root: string, relative: string) {
  if (relative.startsWith('/') || relative.includes('..') || relative.includes('\\')) throw new Error(`مسار ملف غير آمن: ${relative}`);
  return `${root}${relative}`;
}

function normalizeRows(path: string, value: unknown): Array<{id:string; section:string; title:string; body:string; metadata:string}> {
  const rows: Array<{id:string; section:string; title:string; body:string; metadata:string}> = [];
  const add = (item: any, section: string, fallbackId: string, categoryMap: Map<string, string> = new Map()) => {
    if (!item || typeof item !== 'object') return;
    const principle = String(item.principle ?? '').trim();
    const title = String(item.title ?? item.lawName ?? item.name ?? item.heading ?? (principle ? principle.slice(0, 120) : '')).trim();
    if (!title) return;
    const body = String(item.text ?? item.body ?? item.content ?? item.summary ?? principle).trim();
    const id = String(item.id ?? fallbackId);
    const { text: _text, body: _body, content: _content, summary: _summary, ...metadata } = item;
    const rawCategory = String(item.subcategory ?? item.category ?? '').trim();
    const category = categoryMap.get(rawCategory) ?? rawCategory;
    const displaySection = category ? `${section} · ${category}` : section;
    rows.push({ id: `${section}:${id}`, section: displaySection, title, body, metadata: JSON.stringify({ ...metadata, sourceFile: path, sourceSection: section, category }) });
  };
  if (Array.isArray(value)) {
    value.forEach((item: any, i) => add(item, String(item?.sectionLabel ?? sectionFromPath(path)), `${path}:${i}`));
  } else if (value && typeof value === 'object') {
    const obj = value as any;
    const section = String(obj.sectionLabel ?? obj.title ?? obj.section ?? sectionFromPath(path));
    const categoryMap = new Map<string, string>((Array.isArray(obj.subcategories) ? obj.subcategories : [])
      .filter((entry: any) => entry && typeof entry.key === 'string' && typeof entry.title === 'string')
      .map((entry: any) => [entry.key, entry.title]));
    for (const key of ['entries', 'articles', 'pleadings', 'cassationPrinciples']) {
      if (Array.isArray(obj[key])) obj[key].forEach((item: any, i: number) => add(item, String(item?.sectionLabel ?? section), `${path}:${key}:${i}`, categoryMap));
    }
  }
  return rows;
}

function sectionFromPath(path: string) {
  if (path.includes('legalencyclopedia')) return 'الموسوعة القانونية';
  const match = path.match(/mks_v1_([^_]+)/);
  return match ? `المكتبة القانونية - ${match[1]}` : 'بيانات قانونية';
}

async function importOneJson(path: string, file: PackageFile, partRoot: string, packageId: string, progress?: Progress) {
  const uri = safePath(partRoot, file.path);
  const info = await FileSystem.getInfoAsync(uri);
  if (!info.exists || !info.size || info.size !== file.compressedBytes) throw new Error(`حجم الملف المضغوط غير مطابق: ${file.path}`);
  const compressed = await readBytes(uri);
  const compressedHash = sha256(compressed);
  if (compressedHash !== file.sha256) throw new Error(`فشل التحقق من SHA-256 للملف: ${file.path}`);
  const inflated = ungzip(compressed);
  if (inflated.byteLength !== file.uncompressedBytes) throw new Error(`حجم JSON بعد فك الضغط غير مطابق: ${file.path}`);
  const jsonHash = sha256(inflated);
  if (jsonHash !== file.jsonSha256) throw new Error(`فشل التحقق من بصمة JSON: ${file.path}`);
  const jsonText = ungzip(compressed, { to: 'string' }) as unknown as string;
  const parsed = JSON.parse(jsonText) as unknown;
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(
      'INSERT OR REPLACE INTO source_documents(path, package_id, json_sha256, content_json, compressed_gzip) VALUES (?, ?, ?, ?, ?)',
      file.path, packageId, file.jsonSha256, '', compressed,
    );
    const rows = normalizeRows(file.path, parsed);
    for (const row of rows) {
      await db.runAsync(
        `INSERT INTO legal_records(record_id, package_id, section, title, body, metadata_json) VALUES (?, ?, ?, ?, ?, ?)
         ON CONFLICT(record_id) DO UPDATE SET package_id=excluded.package_id, section=excluded.section, title=excluded.title,
         body=CASE WHEN excluded.body <> '' THEN excluded.body ELSE legal_records.body END,
         metadata_json=excluded.metadata_json`,
        row.id, packageId, row.section, row.title, row.body, row.metadata,
      );
    }
  });
  progress?.('استيراد وفهرسة المحتوى', 1, 1);
}

/**
 * Imports all four numbered ZIP files as one atomic logical package.
 * ZIPs are staged independently to avoid overwriting their internal manifests.
 * The live data is not marked complete until every compressed and decompressed
 * file passes both SHA-256 checks and every source JSON has been persisted.
 */
export async function importPackageArchives(archives: PickedArchive[], progress?: Progress) {
  if (archives.length !== 4) throw new Error('يجب اختيار الأجزاء الأربعة معاً لإتمام الاستيراد الأول.');
  await initializeDatabase();
  await FileSystem.makeDirectoryAsync(ROOT, { intermediates: true });
  const runId = `${Date.now()}`;
  const extracted: Array<{ root: string; manifest: PartManifest }> = [];
  const stagedRoots: string[] = [];
  let activePackageId: string | null = null;
  let preserveExistingComplete = false;
  try {
    for (let i = 0; i < archives.length; i++) {
      const root = `${ROOT}stage-${runId}-part-${i + 1}/`;
      await FileSystem.makeDirectoryAsync(root, { intermediates: true });
      stagedRoots.push(root);
      const unzipped = await unzip(archives[i].uri, root);
      const partRoot = unzipped.endsWith('/') ? unzipped : `${unzipped}/`;
      const manifest = await readJson<PartManifest>(`${partRoot}package-manifest.json`);
      extracted.push({ root: partRoot, manifest });
      progress?.('فك الحزم وقراءة بياناتها', i + 1, archives.length);
    }
    const first = extracted[0];
    const masterText = await readText(`${first.root}all-parts-manifest.json`);
    if (sha256(masterText) !== EXPECTED_MASTER_SHA256) throw new Error('بصمة البيان الرئيسي لا تطابق نسخة البيانات الأصلية المعتمدة.');
    const master = JSON.parse(masterText) as AllPartsManifest;
    activePackageId = master.packageId;
    for (const item of extracted) {
      const otherMaster = await readJson<AllPartsManifest>(`${item.root}all-parts-manifest.json`);
      if (JSON.stringify(otherMaster) !== JSON.stringify(master)) throw new Error('بيان الحزمة الرئيسي غير متطابق بين الأجزاء.');
    }
    const validation = validatePackageSet(master, extracted.map(x => x.manifest));
    if (!validation.ok) throw new Error(validation.errors.join('\n'));
    const ordered = [...extracted].sort((a,b) => a.manifest.partNumber - b.manifest.partNumber);
    const db = await getDb();
    const existing = await db.getFirstAsync<{status:string}>('SELECT status FROM import_state WHERE package_id = ?', master.packageId);
    if (existing?.status === 'complete') {
      preserveExistingComplete = true;
      const count = await db.getFirstAsync<{n:number}>('SELECT COUNT(*) AS n FROM imported_packages WHERE package_id = ?', master.packageId);
      if ((count?.n ?? 0) === master.partsTotal) return { alreadyImported: true, files: master.filesTotal };
    }
    if (!preserveExistingComplete) {
      await db.runAsync('INSERT OR REPLACE INTO import_state(package_id,status,total_parts,imported_parts) VALUES (?, ?, ?, 0)', master.packageId, 'importing', master.partsTotal);
    }
    let fileDone = 0;
    for (const item of ordered) {
      const partFiles = item.manifest.files;
      for (const file of partFiles) {
        const saved = await db.getFirstAsync<{sha256:string}>('SELECT sha256 FROM imported_files WHERE package_id = ? AND path = ?', master.packageId, file.path);
        const savedDocument = saved?.sha256 === file.sha256
          ? await db.getFirstAsync<{path:string}>('SELECT path FROM source_documents WHERE package_id = ? AND path = ?', master.packageId, file.path)
          : null;
        if (!savedDocument) {
          await importOneJson(file.path, file, item.root, master.packageId);
          await db.runAsync('INSERT OR REPLACE INTO imported_files(package_id,path,sha256) VALUES (?, ?, ?)', master.packageId, file.path, file.sha256);
        }
        fileDone++;
        progress?.('التحقق من البيانات واستيرادها', fileDone, master.filesTotal);
      }
      const partHash = sha256(JSON.stringify(item.manifest.files));
      await db.runAsync('INSERT OR REPLACE INTO imported_packages(package_id,part_number,sha256) VALUES (?, ?, ?)', master.packageId, item.manifest.partNumber, partHash);
      await db.runAsync('UPDATE import_state SET imported_parts = ?, updated_at = CURRENT_TIMESTAMP WHERE package_id = ?', item.manifest.partNumber, master.packageId);
    }
    const totalDocs = await db.getFirstAsync<{n:number}>('SELECT COUNT(*) AS n FROM source_documents WHERE package_id = ?', master.packageId);
    const verifiedFiles = await db.getFirstAsync<{n:number}>('SELECT COUNT(*) AS n FROM imported_files WHERE package_id = ?', master.packageId);
    if ((totalDocs?.n ?? 0) !== master.filesTotal || (verifiedFiles?.n ?? 0) !== master.filesTotal) throw new Error(`عدد ملفات البيانات المحفوظة غير مكتمل (${totalDocs?.n ?? 0}/${master.filesTotal}).`);
    await db.runAsync("UPDATE import_state SET status = 'complete', imported_parts = total_parts, updated_at = CURRENT_TIMESTAMP WHERE package_id = ?", master.packageId);
    return { alreadyImported: false, files: master.filesTotal, documents: totalDocs?.n ?? 0 };
  } catch (error) {
    const db = await getDb();
    if (activePackageId && !preserveExistingComplete) {
      await db.runAsync("UPDATE import_state SET status = 'failed', updated_at = CURRENT_TIMESTAMP WHERE package_id = ? AND status = 'importing'", activePackageId).catch(() => undefined);
    }
    throw error;
  } finally {
    for (const root of stagedRoots) await FileSystem.deleteAsync(root, { idempotent: true }).catch(() => undefined);
  }
}

export { validatePackageSet };
